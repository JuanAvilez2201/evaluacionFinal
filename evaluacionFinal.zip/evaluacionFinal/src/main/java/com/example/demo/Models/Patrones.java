package com.example.demo.Models;

public class Patrones {

	private String codigo;
	private String descripcion;
	private int id;
	private String nombre;
	private String padre;
	private String uso;

	public Patrones() {
		
	}
	
	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getDescipcion() {
		return descripcion;
	}

	public void setDescipcion(String descipcion) {
		this.descripcion = descipcion;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPadre() {
		return padre;
	}

	public void setPadre(String padre) {
		this.padre = padre;
	}

	public String getUso() {
		return uso;
	}

	public void setUso(String uso) {
		this.uso = uso;
	}
	
	
}
